# 第169章—Kafka消息中间件和RabbitMQ有什么区别
 暂未写作