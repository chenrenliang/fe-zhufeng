# 第177章—为什么要用ElasticSearch做全文检索
 暂未写作